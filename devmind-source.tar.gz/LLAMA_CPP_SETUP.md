# llama.cpp 完整设置指南

## 🎯 完整设置流程

### **步骤 1: 下载和构建 llama.cpp**

```bash
# 1. 克隆 llama.cpp 仓库
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp

# 2. 构建项目（选择适合你系统的方法）

# Linux/macOS (CPU版本)
make

# 或者，如果你有NVIDIA GPU
make LLAMA_CUDA=1

# 或者，如果你有AMD GPU
make LLAMA_HIPBLAS=1

# 或者，使用CMake构建
mkdir build
cd build
cmake ..
make -j 8
cd ..
```

### **步骤 2: 下载模型文件**

你需要下载 GGUF 格式的模型文件。推荐几个编程相关的模型：

#### **方式1: 使用 Hugging Face Hub 下载**
```bash
# 安装 huggingface_hub
pip install huggingface_hub

# 下载模型到 models 目录
mkdir -p models

# 下载 CodeQwen 模型（推荐）
huggingface-cli download Qwen/CodeQwen1.5-7B-Chat-GGUF CodeQwen1.5-7B-Chat.Q4_K_M.gguf --local-dir models

# 下载 Code Llama 模型
huggingface-cli download TheBloke/CodeLlama-7B-Instruct-GGUF CodeLlama-7B-Instruct.Q4_K_M.gguf --local-dir models

# 下载 DeepSeek Coder 模型
huggingface-cli download TheBloke/deepseek-coder-6.7b-instruct-GGUF deepseek-coder-6.7b-instruct.Q4_K_M.gguf --local-dir models
```

#### **方式2: 手动下载**
访问以下链接手动下载：
- [CodeQwen 模型](https://huggingface.co/Qwen/CodeQwen1.5-7B-Chat-GGUF/tree/main)
- [Code Llama 模型](https://huggingface.co/TheBloke/CodeLlama-7B-Instruct-GGUF/tree/main)
- [DeepSeek Coder 模型](https://huggingface.co/TheBloke/deepseek-coder-6.7b-instruct-GGUF/tree/main)

下载 `.gguf` 文件到 `llama.cpp/models/` 目录。

### **步骤 3: 启动服务器**

```bash
# 在 llama.cpp 目录中运行
cd llama.cpp

# 启动服务器 - 使用你下载的模型文件
./server -m models/CodeQwen1.5-7B-Chat.Q4_K_M.gguf --port 8080 --ctx-size 4096

# 或者使用 Code Llama
./server -m models/CodeLlama-7B-Instruct.Q4_K_M.gguf --port 8080 --ctx-size 4096

# 或者使用 DeepSeek Coder
./server -m models/deepseek-coder-6.7b-instruct.Q4_K_M.gguf --port 8080 --ctx-size 4096
```

### **步骤 4: 测试服务器**

```bash
# 在另一个终端中测试
curl http://localhost:8080/v1/models

# 应该返回类似这样的JSON:
# {"object":"list","data":[{"id":"model","object":"model"}]}
```

### **步骤 5: 在 DevMind 中使用**

```bash
# 启动 DevMind
python main.py

# 检查本地模型
devmind> /local

# 切换到 llama.cpp 模型
devmind> /model llama-cpp-local

# 开始对话
devmind> 你好，你能帮我写代码吗？
```

## 📂 **目录结构示例**

设置完成后，你的目录应该如下：

```
/home/your-username/
├── llama.cpp/                    # llama.cpp 主目录
│   ├── server                    # 构建的服务器可执行文件
│   ├── models/                   # 模型文件目录
│   │   ├── CodeQwen1.5-7B-Chat.Q4_K_M.gguf
│   │   ├── CodeLlama-7B-Instruct.Q4_K_M.gguf
│   │   └── deepseek-coder-6.7b-instruct.Q4_K_M.gguf
│   └── ...
└── aiagent/                      # DevMind 目录
    ├── main.py
    └── ...
```

## ⚡ **快速启动脚本**

创建一个启动脚本方便使用：

```bash
# 创建启动脚本
cat > start_llamacpp.sh << 'EOF'
#!/bin/bash
cd /path/to/llama.cpp
echo "启动 llama.cpp 服务器..."
echo "模型: CodeQwen1.5-7B-Chat"
echo "端口: 8080"
echo "按 Ctrl+C 停止服务器"
echo ""
./server -m models/CodeQwen1.5-7B-Chat.Q4_K_M.gguf --port 8080 --ctx-size 4096
EOF

# 设置执行权限
chmod +x start_llamacpp.sh

# 运行
./start_llamacpp.sh
```

## 🔧 **推荐配置**

### **轻量配置 (8GB RAM)**
```bash
./server -m models/CodeQwen1.5-7B-Chat.Q4_K_M.gguf --port 8080 --ctx-size 2048 --threads 4
```

### **标准配置 (16GB RAM)**
```bash
./server -m models/CodeQwen1.5-7B-Chat.Q4_K_M.gguf --port 8080 --ctx-size 4096 --threads 8
```

### **高性能配置 (32GB+ RAM, GPU)**
```bash
./server -m models/CodeLlama-13B-Instruct.Q4_K_M.gguf --port 8080 --ctx-size 8192 --n-gpu-layers 32
```

## 🔍 **故障排除**

### **构建失败**
```bash
# 更新系统依赖
# Ubuntu/Debian
sudo apt update && sudo apt install build-essential cmake

# macOS
brew install cmake

# 清理后重新构建
make clean
make
```

### **模型文件找不到**
```bash
# 检查文件路径
ls -la models/

# 确保文件存在且有正确权限
chmod 644 models/*.gguf
```

### **服务器启动失败**
```bash
# 检查端口是否被占用
netstat -an | grep 8080

# 尝试不同端口
./server -m models/your-model.gguf --port 8081
```

### **内存不足**
```bash
# 使用更小的模型
# 下载 Q4_K_S（更小）而不是 Q4_K_M（中等）版本
# 或者减少 context size
./server -m models/your-model.gguf --port 8080 --ctx-size 1024
```

## 💡 **小贴士**

1. **模型选择**:
   - Q4_K_M: 质量和速度平衡
   - Q4_K_S: 更快但质量稍低
   - Q8_0: 最高质量但最慢

2. **性能优化**:
   - 使用 `--threads` 设置 CPU 线程数
   - 有 GPU 时使用 `--n-gpu-layers` 参数
   - 调整 `--ctx-size` 平衡内存和功能

3. **后台运行**:
   ```bash
   nohup ./server -m models/your-model.gguf --port 8080 > server.log 2>&1 &
   ```

现在你可以按照这些步骤设置 llama.cpp，然后在 DevMind 中使用本地模型了！