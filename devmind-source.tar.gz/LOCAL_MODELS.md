# DevMind 本地模型支持

## 🎯 功能概述

DevMind 现在支持本地运行的开源模型，通过 Ollama 和 llama.cpp 集成，让你可以在本地运行强大的 AI 模型，无需依赖在线服务！

## 🚀 支持的本地模型平台

### **1. Ollama 集成**
- ✅ 简单易用的模型管理
- ✅ 一键安装和运行模型
- ✅ 自动模型发现
- ✅ 完整的 API 兼容性

### **2. llama.cpp 集成**
- ✅ 高性能 GGUF 模型支持
- ✅ OpenAI 兼容 API
- ✅ 灵活的模型配置
- ✅ 低内存占用

## 📋 预配置模型列表

### **Ollama 模型**

| 模型名称 | 描述 | 特长 |
|---------|------|------|
| `llama3.2` | Llama 3.2 | 最新的通用能力模型 |
| `llama3.1` | Llama 3.1 | 大上下文窗口，强性能 |
| `codellama` | Code Llama 7B | 代码生成专用 |
| `codellama:13b` | Code Llama 13B | 更强的代码能力 |
| `codellama:34b` | Code Llama 34B | 最强代码性能 |
| `deepseek-coder` | DeepSeek Coder | 优秀的编程助手 |
| `qwen2.5-coder` | Qwen2.5 Coder | 多语言编程支持 |
| `starcoder2` | StarCoder2 | 高质量代码生成 |
| `mistral` | Mistral 7B | 快速通用模型 |
| `mixtral` | Mixtral 8x7B | 专家混合模型 |
| `phi3` | Phi-3 | 紧凑但强大 |

### **llama.cpp 模型**

| 模型名称 | 描述 | 使用场景 |
|---------|------|---------|
| `llama-cpp-local` | 通用本地模型 | 基础聊天和编程 |
| `llama-cpp-codeqwen` | CodeQwen GGUF | 专业编程任务 |
| `llama-cpp-codellama` | Code Llama GGUF | 代码生成 |

## ⚙️ 安装和设置

### **Ollama 设置**

#### **1. 安装 Ollama**
```bash
# Linux
curl -fsSL https://ollama.com/install.sh | sh

# macOS
brew install ollama

# Windows
# 从 https://ollama.com/download 下载安装包
```

#### **2. 启动 Ollama 服务**
```bash
ollama serve
```

#### **3. 拉取推荐模型**
```bash
# 最新通用模型
ollama pull llama3.2

# 编程专用模型
ollama pull codellama:13b
ollama pull deepseek-coder

# 快速轻量模型
ollama pull mistral
```

### **llama.cpp 设置**

#### **1. 构建 llama.cpp**
```bash
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make
```

#### **2. 下载 GGUF 模型**
从 Hugging Face 下载 GGUF 格式的模型：
- `CodeQwen1.5-7B-Chat.Q4_K_M.gguf`
- `CodeLlama-13B-Instruct.Q4_K_M.gguf`
- `deepseek-coder-6.7b-instruct.Q4_K_M.gguf`

#### **3. 启动服务器**
```bash
# 启动 OpenAI 兼容服务器
./server -m models/your-model.gguf -c 4096 --port 8080

# 或者使用别名（更易使用）
./server --model models/CodeQwen1.5-7B-Chat.Q4_K_M.gguf --ctx-size 4096 --port 8080 --alias codellama
```

## 🔧 DevMind 中的使用

### **基本命令**

#### **检查本地模型**
```bash
devmind> /local
🏠 Local Model Servers
┏━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━━━━┓
┃ Server  ┃ Provider ┃ URL                  ┃ Status ┃ Models          ┃
┡━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━━━━┩
│ ollama  │ Ollama   │ http://localhost:... │ ● Ac.. │ llama3.2, co... │
│ llama..
```

#### **Ollama 帮助**
```bash
devmind> /ollama
🦙 Ollama Integration
✓ Ollama server found with 5 models:
  • llama3.2
  • codellama:13b
  • deepseek-coder

Quick start:
  /model llama3.2
```

#### **llama.cpp 帮助**
```bash
devmind> /llamacpp
🦙 llama.cpp Integration
✓ llama.cpp server found with 2 models:
  • codeqwen-7b
  • codellama-13b

Quick start:
  /model llama-cpp-local
```

### **切换到本地模型**
```bash
# 使用 Ollama 模型
devmind> /model llama3.2
✓ Switched to llama3.2

# 使用 llama.cpp 模型
devmind> /model llama-cpp-local
✓ Switched to llama-cpp-local
```

### **实际开发示例**
```bash
devmind> /model deepseek-coder
✓ Switched to deepseek-coder
Provider: Ollama
Description: DeepSeek Coder - Excellent for programming tasks

devmind> 帮我写一个Python快速排序函数
💭 开始分析任务
💭 用户需要Python快速排序函数，我来编写一个高效的实现

def quicksort(arr):
    """
    快速排序算法实现

    Args:
        arr: 要排序的数组

    Returns:
        排序后的数组
    """
    if len(arr) <= 1:
        return arr

    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]

    return quicksort(left) + middle + quicksort(right)

# 使用示例
if __name__ == "__main__":
    data = [64, 34, 25, 12, 22, 11, 90]
    sorted_data = quicksort(data)
    print(f"原数组: {data}")
    print(f"排序后: {sorted_data}")
```

## 🎯 推荐配置

### **开发者推荐配置**

#### **轻量开发环境 (8GB RAM)**
```bash
ollama pull mistral      # 快速通用
ollama pull deepseek-coder # 编程专用
```

#### **标准开发环境 (16GB RAM)**
```bash
ollama pull llama3.2      # 最新能力
ollama pull codellama:13b # 强代码能力
ollama pull deepseek-coder # 编程助手
```

#### **专业开发环境 (32GB+ RAM)**
```bash
ollama pull llama3.1      # 大上下文
ollama pull codellama:34b # 最强编程
ollama pull mixtral       # 专家混合
ollama pull qwen2.5-coder # 多语言支持
```

### **模型选择指南**

| 任务类型 | 推荐模型 | 说明 |
|---------|---------|------|
| 代码生成 | `codellama:13b`, `deepseek-coder` | 专业编程能力 |
| 代码审查 | `qwen2.5-coder`, `codellama:34b` | 深度理解代码 |
| 快速原型 | `mistral`, `phi3` | 轻量快速 |
| 复杂推理 | `llama3.2`, `mixtral` | 强逻辑能力 |
| 大型项目 | `llama3.1`, `codellama:34b` | 大上下文支持 |

## 🔍 故障排除

### **常见问题**

#### **Ollama 连接失败**
```bash
# 检查服务状态
ollama ps

# 重启服务
ollama serve

# 检查端口
netstat -an | grep 11434
```

#### **llama.cpp 连接失败**
```bash
# 检查服务器进程
ps aux | grep server

# 检查端口
netstat -an | grep 8080

# 确保启动时使用正确的端点
./server -m models/your-model.gguf --port 8080

# 测试服务器是否正常运行
curl http://localhost:8080/v1/models
```

#### **LiteLLM Provider 错误**
如果遇到 "LLM Provider NOT provided" 错误：
- ✅ 确保 llama.cpp 服务器在 `http://localhost:8080` 运行
- ✅ 使用 `/local` 命令检查服务器状态
- ✅ llama.cpp 模型会自动映射为 `openai/model-name` 格式

#### **模型加载慢**
- 确保有足够的 RAM
- 使用较小的模型版本 (Q4_K_M vs Q8_0)
- 检查磁盘空间和 I/O 性能

#### **响应质量差**
- 尝试更大的模型版本
- 调整温度参数: `/model mistral --temperature 0.3`
- 确保模型适合任务类型

## 🚀 性能优化

### **Ollama 优化**
```bash
# 设置 GPU 加速 (如果有 NVIDIA GPU)
ollama pull llama3.2 --gpu

# 调整并发连接
OLLAMA_NUM_PARALLEL=2 ollama serve
```

### **llama.cpp 优化**
```bash
# GPU 加速
./server -m model.gguf -ngl 32

# 调整线程数
./server -m model.gguf -t 8

# 内存映射优化
./server -m model.gguf --mlock
```

## 🔧 高级配置

### **自定义端点**
DevMind 支持自定义 Ollama 和 llama.cpp 端点配置。

### **环境变量**
```bash
# Ollama 端点
export OLLAMA_HOST=http://localhost:11434

# llama.cpp 端点
export LLAMACPP_HOST=http://localhost:8080
```

### **多服务器支持**
可以同时运行多个 Ollama 和 llama.cpp 实例，DevMind 会自动发现并管理。

## 📊 性能对比

| 模型 | 大小 | RAM需求 | 推理速度 | 代码质量 |
|------|------|---------|----------|----------|
| `mistral` | 7B | 8GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| `codellama:13b` | 13B | 16GB | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| `deepseek-coder` | 7B | 8GB | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| `mixtral` | 8x7B | 24GB | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

## 🎯 最佳实践

### **开发工作流程**
1. **快速原型**: 使用 `mistral` 或 `phi3`
2. **代码开发**: 切换到 `deepseek-coder` 或 `codellama:13b`
3. **代码审查**: 使用 `qwen2.5-coder` 进行深度分析
4. **复杂架构**: 使用 `llama3.2` 或 `mixtral`

### **资源管理**
- 根据可用内存选择合适大小的模型
- 使用 `/local` 命令监控服务器状态
- 定期清理不使用的模型

### **质量保证**
- 对比多个模型的输出质量
- 针对特定任务选择专用模型
- 保存最佳配置为会话

---

DevMind 的本地模型支持让你拥有完全的隐私控制和无限制的使用！🚀