# Ollama 快速设置指南

## 🚀 为什么选择 Ollama？

- ✅ **超级简单**: 一个命令安装，一个命令运行
- ✅ **自动管理**: 自动下载、更新和管理模型
- ✅ **即开即用**: 无需手动构建或配置
- ✅ **模型丰富**: 支持最新的开源模型
- ✅ **性能优化**: 针对不同硬件自动优化

## ⚡ **超快速设置 (3分钟搞定)**

### **第1步: 安装 Ollama**

#### **Linux (推荐)**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

#### **macOS**
```bash
# 使用 Homebrew
brew install ollama

# 或者下载安装包
# 访问 https://ollama.com/download
```

#### **Windows**
```bash
# 下载并运行安装包
# 访问 https://ollama.com/download/windows
```

### **第2步: 启动 Ollama 服务**
```bash
# 启动服务（后台运行）
ollama serve
```

### **第3步: 拉取编程模型**
```bash
# 拉取推荐的编程模型（选择一个或多个）

# 最新最强 - Llama 3.2 (推荐)
ollama pull llama3.2

# 编程专用 - DeepSeek Coder
ollama pull deepseek-coder

# 代码生成 - Code Llama 13B
ollama pull codellama:13b

# 快速轻量 - Mistral
ollama pull mistral

# 多语言编程 - Qwen2.5 Coder
ollama pull qwen2.5-coder
```

### **第4步: 在 DevMind 中使用**
```bash
# 启动 DevMind
python main.py

# 检查 Ollama 状态
devmind> /ollama

# 查看所有本地模型
devmind> /local

# 切换到 Ollama 模型
devmind> /model llama3.2

# 开始编程对话
devmind> 帮我写一个Python快速排序函数
```

## 🎯 **推荐模型配置**

### **新手推荐 (选择1-2个)**
```bash
ollama pull llama3.2      # 最新通用模型
ollama pull deepseek-coder # 编程专用
```

### **开发者推荐 (选择2-3个)**
```bash
ollama pull llama3.2      # 最新通用
ollama pull codellama:13b # 强代码能力
ollama pull deepseek-coder # 编程助手
ollama pull mistral       # 快速轻量
```

### **专业开发者 (全套)**
```bash
ollama pull llama3.2      # 最新通用
ollama pull codellama:13b # 代码生成
ollama pull deepseek-coder # 编程理解
ollama pull qwen2.5-coder # 多语言
ollama pull starcoder2    # 高质量代码
ollama pull mistral       # 快速原型
ollama pull phi3          # 紧凑模型
```

## 📊 **模型对比表**

| 模型 | 大小 | 内存需求 | 编程能力 | 通用能力 | 速度 |
|------|------|----------|----------|----------|------|
| `llama3.2` | 4.7GB | 8GB | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| `deepseek-coder` | 3.8GB | 6GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| `codellama:13b` | 7.3GB | 16GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| `mistral` | 4.1GB | 8GB | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| `qwen2.5-coder` | 4.2GB | 8GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

## 🔧 **常用 Ollama 命令**

### **模型管理**
```bash
# 查看已安装模型
ollama list

# 拉取新模型
ollama pull model-name

# 删除模型
ollama rm model-name

# 更新模型
ollama pull model-name
```

### **直接测试模型**
```bash
# 直接在命令行测试（无需 DevMind）
ollama run llama3.2
# 然后就可以直接对话了

# 退出测试
/bye
```

### **服务管理**
```bash
# 启动服务
ollama serve

# 检查服务状态
ollama ps

# 查看运行中的模型
ollama ps
```

## 🚀 **完整设置示例**

假设你是 Python 开发者，以下是完整的设置流程：

```bash
# 1. 安装 Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. 启动服务
ollama serve &

# 3. 拉取推荐模型
ollama pull llama3.2
ollama pull deepseek-coder

# 4. 验证安装
ollama list

# 5. 启动 DevMind
cd ~/workspace/aiagent
python main.py

# 6. 在 DevMind 中使用
# devmind> /ollama
# devmind> /model llama3.2
# devmind> 帮我写一个 Web API
```

## 🔍 **故障排除**

### **服务启动失败**
```bash
# 检查是否已经在运行
ollama ps

# 杀掉现有进程后重启
pkill ollama
ollama serve
```

### **模型下载慢**
```bash
# 设置国内镜像（如果在中国）
export OLLAMA_MIRRORS="https://ollama.hf.space,https://ollama-models.zwc365.com"
ollama pull llama3.2
```

### **内存不足**
```bash
# 使用更小的模型
ollama pull phi3        # 3.8GB
ollama pull llama3.2:8b # 如果默认太大，尝试指定大小
```

### **端口冲突**
```bash
# 修改默认端口（默认11434）
export OLLAMA_HOST=0.0.0.0:11435
ollama serve
```

## 📱 **一键启动脚本**

创建方便的启动脚本：

```bash
# 创建 Ollama 启动脚本
cat > ~/start_ollama_dev.sh << 'EOF'
#!/bin/bash
echo "🦙 启动 Ollama 开发环境..."

# 检查 Ollama 是否已运行
if ! pgrep -x "ollama" > /dev/null; then
    echo "📍 启动 Ollama 服务..."
    ollama serve &
    sleep 3
else
    echo "✅ Ollama 服务已运行"
fi

# 显示可用模型
echo "📋 可用模型:"
ollama list

echo ""
echo "🚀 Ollama 就绪！"
echo "💡 使用示例:"
echo "   devmind> /model llama3.2"
echo "   devmind> /model deepseek-coder"
EOF

chmod +x ~/start_ollama_dev.sh

# 运行
~/start_ollama_dev.sh
```

## 🎯 **DevMind 集成测试**

设置完成后，在 DevMind 中测试：

```bash
# 启动 DevMind
python main.py

# 测试 Ollama 集成
devmind> /ollama
🦙 Ollama Integration
✓ Ollama server found with 3 models:
  • llama3.2
  • deepseek-coder
  • mistral

# 切换模型测试
devmind> /model deepseek-coder
✓ Switched to deepseek-coder
Provider: Ollama
Description: DeepSeek Coder - Excellent for programming tasks

# 测试编程能力
devmind> 帮我写一个 FastAPI 应用的基础结构
```

## 🏆 **最佳实践**

1. **首次使用**: 先拉取 `llama3.2` 和 `deepseek-coder`
2. **日常开发**: 主要使用 `deepseek-coder` 进行编程
3. **复杂推理**: 切换到 `llama3.2` 进行架构设计
4. **快速原型**: 使用 `mistral` 获得快速响应
5. **定期更新**: `ollama pull model-name` 更新模型

Ollama 比 llama.cpp 简单太多了！现在就试试吧！🚀